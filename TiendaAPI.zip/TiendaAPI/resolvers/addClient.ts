import { Request, Response } from "express"; // Asegúrate de importar express adecuadamente
import { ClientModelType } from "../db/client.ts";

const addClient = async (req : Request, res: Response) => {
  try {
    const { name, cif } = req.body;
    if (!name || !cif) {
      res.status(400).send("Name and cif are required");
      return;
    }

    const alreadyExists = await ClientModelType.findOne({ cif }).exec();
    if (alreadyExists) {
      res.status(400).send("Client already exists");
      return;
    }

    const newClient = new ClientModelType({ name, cif });
    await newClient.save();

    res.status(200).send({
      name: newClient.name,
      cif: newClient.cif, // Cambiado "age" a "cif"
      id: newClient._id.toString(),
    });
  } catch (error) {
    res.status(500).send(error.message);
    return;
  }
};

export default addClient;
