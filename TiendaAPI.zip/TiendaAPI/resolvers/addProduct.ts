import { Request, Response } from "express";
import { ProductModelType } from "../db/product.ts";

const addProduct = async (req: Request, res: Response) => {
  try {
    const { name, description, price, stock = 0 } = req.body;

    if (!name || !price) {
      res.status(400).send("Name and price are required");
      return;
    }

    const alreadyExists = await ProductModelType.findOne({ name }).exec();
    if (alreadyExists) {
      res.status(400).send("Product already exists");
      return;
    }

    const newProduct = new ProductModel({ name, description, price, stock });
    await newProduct.save();

    res.status(201).json(newProduct);
  } catch (error) {
    res.status(500).send(error.message);
  }
};

export default addProduct;
