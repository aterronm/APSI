import mongoose from "npm:mongoose@8.0.0";
import { Product } from "../types.ts";

const Schema = mongoose.Schema;

const productSchema = new Schema (

    {
    name : { type : String, required : true },
    stock : { type : Number, default : 0},
    description : { type : String },
    price : { type : Number, required : true }
    },

    { timestamps : true }
);

export type ProductModelType = mongoose.Document & Omit <Product, "id">;
export default mongoose.model<ProductModelType>("Product", productSchema);

